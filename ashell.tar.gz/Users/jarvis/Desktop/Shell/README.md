Erick Cruz (SID: 912269308)

Vanessa Kha (SID: 914134981)

http://codewiki.wikidot.com/c:system-calls:stat

We used this source to print access permissions before each file found by ls.


https://stackoverflow.com/questions/15883568/reading-from-stdin


We used this source to figure out how to read input from stdin. We learned that it was helpful to read each character one by one using the 'read' system call.


https://www.ibm.com/support/knowledgecenter/en/SSLTBW_2.3.0/com.ibm.zos.v2r3.bpxbd00/rtread.htm


This source gave us a useful example of how to use dirent.h, specifically how to open a directory and traverse through its contents. We used this to recurse through directories in 'ff'.



http://alumni.cs.ucr.edu/~drougas/code-samples-tutorials/pipe-redirection.c This example gave us structure on how and when to fork for a pipe call, direct file descriptors, and close them when they are no longer needed.

